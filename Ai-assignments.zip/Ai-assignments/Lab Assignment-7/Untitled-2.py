
# Student Grade System - Refactored Code

def get_student_details():
    name = input("Enter Student Name: ")
    roll_no = input("Enter Roll Number: ")
    return name, roll_no


def calculate_marks(subjects):
    total = 0
    failed = False

    for i in range(1, subjects + 1):
        marks = float(input(f"Enter marks for Subject {i}: "))

        if marks < 0 or marks > 100:
            print("Invalid marks! Enter between 0 and 100.")
            return calculate_marks(subjects)

        total += marks

        if marks < 40:
            failed = True

    return total, failed


def calculate_grade(percentage, failed):

    if failed:
        return "F", 0.0, "FAIL"

    elif percentage >= 90:
        return "A+", 10.0, "PASS"

    elif percentage >= 80:
        return "A", 9.0, "PASS"

    elif percentage >= 70:
        return "B", 8.0, "PASS"

    elif percentage >= 60:
        return "C", 7.0, "PASS"

    elif percentage >= 50:
        return "D", 6.0, "PASS"

    else:
        return "E", 5.0, "PASS"


def display_result(name, roll_no, total, subjects,
                   percentage, grade, cgpa, result):

    print("\n===== STUDENT RESULT =====")
    print("Student Name:", name)
    print("Roll Number:", roll_no)
    print("Total Marks:", total, "/", subjects * 100)
    print("Percentage:", round(percentage, 2), "%")
    print("Grade:", grade)
    print("CGPA:", cgpa)
    print("Result:", result)


def main():

    print("===== STUDENT GRADE SYSTEM =====")

    name, roll_no = get_student_details()

    subjects = int(input("Enter number of subjects: "))

    if subjects <= 0:
        print("Number of subjects must be positive.")
        return

    total, failed = calculate_marks(subjects)

    percentage = total / subjects

    grade, cgpa, result = calculate_grade(percentage, failed)

    display_result(
        name, roll_no, total, subjects,
        percentage, grade, cgpa, result
    )


main()
