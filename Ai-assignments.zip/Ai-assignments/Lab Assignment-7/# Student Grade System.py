# Student Grade System

print("===== STUDENT GRADE SYSTEM =====")

name = input("Enter Student Name: ")
roll_no = input("Enter Roll Number: ")

subjects = int(input("Enter number of subjects: "))

total = 0
failed = False

for i in range(1, subjects + 1):
    marks = float(input(f"Enter marks for Subject {i} (out of 100): "))
    total += marks

    if marks < 40:
        failed = True

percentage = total / subjects

if failed:
    result = "FAIL"
    grade = "F"
    cgpa = 0.0
elif percentage >= 90:
    result = "PASS"
    grade = "A+"
    cgpa = 10.0
elif percentage >= 80:
    result = "PASS"
    grade = "A"
    cgpa = 9.0
elif percentage >= 70:
    result = "PASS"
    grade = "B"
    cgpa = 8.0
elif percentage >= 60:
    result = "PASS"
    grade = "C"
    cgpa = 7.0
elif percentage >= 50:
    result = "PASS"
    grade = "D"
    cgpa = 6.0
else:
    result = "PASS"
    grade = "E"
    cgpa = 5.0

print("\n===== STUDENT RESULT =====")
print("Student Name:", name)
print("Roll Number:", roll_no)
print("Total Marks:", total, "/", subjects * 100)
print("Percentage:", round(percentage, 2), "%")
print("Grade:", grade)
print("CGPA:", cgpa)
print("Result:", result) 